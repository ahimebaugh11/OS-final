import sys
from mailpile.app import Main


def main():
    Main(sys.argv[1:])


if __name__ == "__main__":
    main()
