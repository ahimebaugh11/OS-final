# package marker.

__version__ = "1.1b3"
__date__ = "Nov 23, 2017"

from classifier import Classifier
