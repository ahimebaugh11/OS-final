# TODOs #

Things that really should be done to improve the windows experience, in no
particular order.

  - Change the after-install mailpile launch to launch hidden
  - Integrate signing
  - Improve language support
  - Better per-file management in packaging(hash-correlation per path)
