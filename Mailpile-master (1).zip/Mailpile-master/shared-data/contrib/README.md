## Plugins

These are the default plugins that we ship with Mailpile.

Developers: Check out the `demos` plugin and see our github wiki for
details on how to write your own.

Per-user plugins may go in `$MAILPILE_HOME/$MAILPILE_PROFILE/plugins`.

