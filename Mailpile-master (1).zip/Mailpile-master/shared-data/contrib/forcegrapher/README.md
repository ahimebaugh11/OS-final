Use The Force, Grapher
======================

Visualizes your Inbox or any Mailpile search result as a helpful force-directed graph
