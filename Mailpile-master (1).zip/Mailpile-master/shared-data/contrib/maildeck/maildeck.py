from mailpile.commands import Command

class maildeckCommand(Command):
           HTTP_CALLABLE = ('GET',)