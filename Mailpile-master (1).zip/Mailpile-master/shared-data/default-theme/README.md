Mailpile "Default" Theme
========================

This is a "Default" theme that ships with Mailpile and is rendered in the web interface.

To help develop or extend this theme, please follow our [FrontEnd Development Guide](https://github.com/mailpile/Mailpile/wiki/Front-End-Development-Guide)

Eventually, we will flesh out the ability to create alternate themes that are wholly unique Mailpile themes.
