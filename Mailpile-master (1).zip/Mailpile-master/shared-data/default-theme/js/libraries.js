console.log("Mailpile 3rd-party JS library bundle, built at: @MP_JSBUILD_INFO@");
/*
 * All code is Copyright the respective upstream projects. The license for
 * this combined bundle is the same as for Mailpile itself, AGPLv3.
 */
