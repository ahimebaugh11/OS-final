{% import 'page/template-straw-man/tags.html' as tags %}
{{ tags.render_json() }}
