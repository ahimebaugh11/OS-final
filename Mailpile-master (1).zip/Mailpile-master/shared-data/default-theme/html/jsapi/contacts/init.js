/* Contacts */

Mailpile.Contacts = {};
Mailpile.Contacts.UI = {};


Mailpile.Contacts.init = function() {

  // Search Bar
  $('#search-query').val('contacts: ');

  // Hide Key Details
  $('.contact-key-details').hide();

};