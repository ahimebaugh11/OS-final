/* Compose - Complete */

Mailpile.Composer.Complete = function(mid) {
  Mailpile.go(Mailpile.urls.message_sent + mid + "/");
};
